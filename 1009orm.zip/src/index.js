import express from "express";
import "dotenv/config";

import { sequelize } from "./utils/database.js";
import { User } from "./models/User.model.js";
import { Role } from "./models/Role.model.js";

User.belongsToMany(Role, { through: "UserRole" });
Role.belongsToMany(User, { through: "UserRole" });

const app = express();
app.use(express.json());

app.listen(3300, async () => {
  console.log("Elindult az app: http://localhost:3300");

  try {
    await sequelize.sync({ alter: true });
  } catch (error) {
    console.log(error);
  }
});
