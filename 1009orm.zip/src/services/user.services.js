import { User } from "../models/User.model";
import { Role } from "../models/Role.model";

export async function getAll() {
  const user = await user.findAll({
    include: Role,
  });

  return user;
}

export async function getById() {
  return await User.findByPk(id, {
    include: Role,
  });
}

export async function create(username, fullName, password, email) {
  const user = await User.create({
    username,
    fullName,
    password,
    email,
  });

  return user;
}

export async function update(fullName, password, id) {
  const user = await User.findByPk(id);

    
}
