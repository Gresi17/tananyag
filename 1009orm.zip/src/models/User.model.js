import { sequelize } from "../utils/database.js";
import { DataTypes } from "sequelize";

export const User = sequelize.define(
  "User",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      primaryKey: true,
    },
    // id-t nem kell csinálni, alapból lértehozza
    username: DataTypes.STRING,
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isEmail: true,
      },
    },
    fullName: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    password: DataTypes.STRING,
  },
  {
    tableName: "users",
    timestamps: true,
  },
);
